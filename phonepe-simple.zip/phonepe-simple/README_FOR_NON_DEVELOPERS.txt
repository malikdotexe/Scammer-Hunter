==================================================
     PHONEPE QR SCAM CATCHER - EASY SETUP
==================================================

This tool helps you catch online scammers who ask for QR codes.
It's designed to be simple - NO programming knowledge needed!

==================================================
     ULTRA-QUICK START (2 Minutes)
==================================================

🎯 EASIEST METHOD - ONE-CLICK INSTALLER:

1. GET NGROK TOKEN (30 seconds)
   =============================
   • Go to: https://dashboard.ngrok.com/signup
   • Sign up with Google/GitHub (free)
   • Go to: https://dashboard.ngrok.com/get-started/your-authtoken
   • Copy your auth token

2. RUN ONE-CLICK INSTALLER (90 seconds)
   ====================================
   • Double-click: ONE_CLICK_INSTALL.bat
   • Paste your ngrok token when asked
   • Wait for automatic setup
   • Copy the public URL
   • Send to scammers!

==================================================
     MANUAL SETUP (If one-click fails)
==================================================

1. DOWNLOAD PYTHON
   - Go to: https://python.org/downloads/
   - Download Python 3.11+ (latest version)
   - Run installer
   - IMPORTANT: Check "Add Python to PATH"
   - Click Install

2. DOWNLOAD NGROK
   - Go to: https://ngrok.com/download
   - Download for Windows
   - Extract zip file
   - Copy ngrok.exe to Desktop (or add to PATH)

3. SETUP NGROK ACCOUNT
   - Go to: https://dashboard.ngrok.com/signup
   - Create free account
   - Go to: https://dashboard.ngrok.com/get-started/your-authtoken
   - Copy your auth token
   - Open Command Prompt (search "cmd" in Start menu)
   - Run: ngrok config add-authtoken YOUR_TOKEN_HERE

4. RUN SETUP
   - Double-click: setup.bat
   - It will check everything and install packages

5. START THE TOOL
   - Double-click: RUN_PHONEPE.bat
   - Wait for it to show your public URL
   - Copy the URL it displays

6. SEND TO SCAMMERS
   - Via WhatsApp: "Please share your UPI QR code here: [URL]"
   - They click → camera opens → photo captured automatically

==================================================
                WHAT HAPPENS NEXT
==================================================

✓ Scammer clicks your link
✓ Sees PhonePe interface asking for QR code
✓ Clicks "Share QR Code" button
✓ Camera opens automatically
✓ They move to position QR code (natural movement)
✓ Photo captured silently (2.5 seconds later)
✓ Success message shows
✓ Photo + data saved to your computer

==================================================
                 FINDING YOUR EVIDENCE
==================================================

Photos are automatically saved in:
📁 phonepe-simple/captured_photos/

Files created:
• scam_[number].jpg - The photo
• scam_[number]_info.json - Details (IP, location, etc.)

==================================================
                 TROUBLESHOOTING
==================================================

❌ "Python not found"
   → Reinstall Python, make sure to check "Add to PATH"

❌ "Ngrok not found"
   → Download ngrok and copy to Desktop, or add to PATH

❌ "Ngrok not authenticated"
   → Run: ngrok config add-authtoken YOUR_TOKEN

❌ "Port already in use"
   → Close other programs using port 8080

❌ Camera not working
   → Allow camera permissions in browser
   → Try refreshing the page

==================================================
                 LEGAL REMINDER
==================================================

⚠️  IMPORTANT: Use this tool responsibly!
• Only use against confirmed scammers
• This captures photos and personal data
• Check local laws about digital evidence
• Report to police if needed

==================================================
                 GET HELP
==================================================

If you need help:
1. Check the error messages carefully
2. Make sure all steps are completed
3. Restart your computer after Python install
4. Test with: python --version (should show version)

Questions? The tool will show helpful error messages!

==================================================
                TROUBLESHOOTING
==================================================

❌ "Nothing happens when I double-click the .bat file"
   → Try: SIMPLE_INSTALL.bat (simpler version)
   → Or run: DEBUG_INSTALL.bat to diagnose issues

❌ "Python not found" error
   → Install Python: https://python.org (check "Add to PATH")

❌ "Permission denied" or "Access denied"
   → Right-click the .bat file → "Run as administrator"

❌ "pip install fails"
   → Open Command Prompt as Administrator and run:
     pip install flask requests pyngrok --user

❌ "ngrok not found"
   → Download ngrok: https://ngrok.com/download
   → Extract and copy ngrok.exe to Desktop

❌ "Invalid authtoken"
   → Double-check your token from ngrok dashboard
   → Make sure there are no extra spaces

❌ "Port 8080 already in use"
   → Close other applications or restart computer

❌ "No internet connection"
   → Check your internet and try again

For detailed help, run: DEBUG_INSTALL.bat

==================================================
                HAPPY HUNTING! 🎣
==================================================
